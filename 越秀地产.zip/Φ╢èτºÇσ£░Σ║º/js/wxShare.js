function wxshares(shareUrl,shareIamge ,shareTitle, shareDesc) {
	// 微信分享地址 
	//var shareUrl = "http://www.newindex.cn/h5/wmf_submit/index.html";
	//  微信分享图片
	// var shareIamge = "http://www.newindex.cn/h5/xinYiGuangChang/img/share.jpg";
	//  微信分享标题
	//var shareTitle = "致敬 每一个苏州梦";
//	//微信分享描述
	//var shareDesc = "算一算你的苏州年龄";
	var fields = {
		url: window.location.href
	};
	var appIddata, timestampdata, nonceStrdata, signaturedata;
	$.ajax({
		type: "POST",
		url: "share.php",
		async: true,
		data: fields,
		success: function(msg) {
			var data = JSON.parse(msg);
			appIddata = data.appId;
			timestampdata = data.timestamp;
			nonceStrdata = data.nonceStr;
			signaturedata = data.signature;

			wx.config({
				appId: appIddata,
				timestamp: timestampdata,
				nonceStr: nonceStrdata,
				signature: signaturedata,
				jsApiList: [
					// 所有要调用的 API 都要加到这个列表中
					"onMenuShareTimeline",
					"onMenuShareAppMessage",
					"openLocation",
				]
			});
		}
	});
	wx.ready(function() {
		// 在这里调用 API
		wx.onMenuShareTimeline({
			title: shareTitle, // 分享标题
			link: shareUrl, // 分享链接
			imgUrl: shareIamge, // 分享图标
			success: function() {
				// 用户确认分享后执行的回调函数
			},
			cancel: function() {
				// 用户取消分享后执行的回调函数
			}
		});
		wx.onMenuShareAppMessage({
			title: shareTitle, // 分享标题
			desc: shareDesc, // 分享描述
			link: shareUrl, // 分享链接
			imgUrl: shareIamge, // 分享图标
			type: '', // 分享类型,music、video或link，不填默认为link
			dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
			success: function() {
				// 用户确认分享后执行的回调函数
			},
			cancel: function() {
				// 用户取消分享后执行的回调函数
			}
		});
	});
}