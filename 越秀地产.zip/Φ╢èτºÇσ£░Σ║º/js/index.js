
//   laod
var imgNum = 0;
var imgSrc = [];
var aImg = $("img");
for(var i = 0; i < aImg.length; i++) {
    imgSrc.push(aImg[i].src);
}

$.imgpreload(imgSrc, {
    each: function() {
        /*this will be called after each image loaded*/
        var status = $(this).data('loaded') ? 'success' : 'error';
        if(status == "success") {
            var v = (parseFloat(++imgNum) / (imgSrc.length)).toFixed(2);
            console.log(v);
            $(".num").html(Math.round(v * 100) + "%");
            $(".num3").css("width",Math.round(v * 100) + "%");
        }
    },
    all: function() {
        /*this will be called after all images loaded*/
        setTimeout(function() {

            $(".loading").fadeOut();

        }, 1000)

    }
});

var oMusic = document.getElementById("music");
oMusic.play();
document.addEventListener("WeixinJSBridgeReady", function() {
    oMusic.play();
}, false);
var off = true;
$(".music").bind("touchstart", function() {
    if (off) {
        $(this).attr("src", "images/musicoff.png");
        $(this).removeClass("rota");
        oMusic.pause();
        off = false;
    } else {
        $(this).attr("src", "images/music.png");
        $(this).addClass("rota");
        oMusic.play();
        off = true;
    }
})

var windowHeight = document.documentElement.clientHeight;
document.body.style.height = windowHeight + 'px';

$("#quwei").click(function(){
  var obj = {
            urls : ['img/quwei.png'],
            current : 'img/quwei.png'
        };
  previewImage.start(obj);
})



  $("#startBtn").click(function(){
    $("#page1").hide();
    $("#page2").show();
  })



var arr = [true,true,true,true,true,true];
function randomAddClass(){
    for( var i = 0; i<6; i++){
        if (arr[i]) {
            $("#btn"+(i+1)+" span").attr("class","btnArrow arrowMove");
            return;
        }
    }
}

  var mySwiper;
  $("#btn1").click(function(){
    $("#btn1 span").attr("class","btnArrow");
    arr[0] = false;
    randomAddClass()
      mySwiper = new Swiper ('.swiperContainer1', {
        direction: 'vertical',
        effect : 'fade',
        fadeEffect: {
          crossFade: false,
        },
        on:{
          init: function(){
            swiperAnimateCache(this); //隐藏动画元素 
            swiperAnimate(this); //初始化完成开始动画
          }, 
          slideChangeTransitionEnd: function(){ 
            swiperAnimate(this); //每个slide切换结束时也运行当前slide动画
          } 
        }

      })  
    $(".swiperContainer1").css({"z-index":101,"position":"absolute","top":0});
  })
  $("#btn2").click(function(){
    $("#btn2 span").attr("class","btnArrow");
    arr[3] = false;
    randomAddClass()
      mySwiper = new Swiper ('.swiperContainer4', {
        direction: 'vertical',
        effect : 'fade',
        fadeEffect: {
          crossFade: false,
        },
        on:{
          init: function(){
            swiperAnimateCache(this); //隐藏动画元素 
            swiperAnimate(this); //初始化完成开始动画
          }, 
          slideChangeTransitionEnd: function(){ 
            swiperAnimate(this); //每个slide切换结束时也运行当前slide动画
          } 
        }

      })  
    $(".swiperContainer4").css({"z-index":101,"position":"absolute","top":0});
  })
  $("#btn3").click(function(){
    $("#btn3 span").attr("class","btnArrow");
    arr[4] = false;
    randomAddClass()
      mySwiper = new Swiper ('.swiperContainer5', {
        direction: 'vertical',
        effect : 'fade',
        fadeEffect: {
          crossFade: false,
        },
        on:{
          init: function(){
            swiperAnimateCache(this); //隐藏动画元素 
            swiperAnimate(this); //初始化完成开始动画
          }, 
          slideChangeTransitionEnd: function(){ 
            swiperAnimate(this); //每个slide切换结束时也运行当前slide动画
          } 
        }

      })  
    $(".swiperContainer5").css({"z-index":101,"position":"absolute","top":0});
  })
  $("#btn4").click(function(){
    $("#btn4 span").attr("class","btnArrow");
    arr[5] = false;
    randomAddClass()
      mySwiper = new Swiper ('.swiperContainer6', {
        direction: 'vertical',
        effect : 'fade',
        fadeEffect: {
          crossFade: false,
        },
        on:{
          init: function(){
            swiperAnimateCache(this); //隐藏动画元素 
            swiperAnimate(this); //初始化完成开始动画
          }, 
          slideChangeTransitionEnd: function(){ 
            swiperAnimate(this); //每个slide切换结束时也运行当前slide动画
          } 
        }

      })  
    $(".swiperContainer6").css({"z-index":101,"position":"absolute","top":0});
  })
  $("#btn5").click(function(){
    $("#btn5 span").attr("class","btnArrow");
    arr[1] = false;
    randomAddClass()
      mySwiper = new Swiper ('.swiperContainer2', {
        direction: 'vertical',
        effect : 'fade',
        fadeEffect: {
          crossFade: false,
        },
        on:{
          init: function(){
            swiperAnimateCache(this); //隐藏动画元素 
            swiperAnimate(this); //初始化完成开始动画
          }, 
          slideChangeTransitionEnd: function(){ 
            swiperAnimate(this); //每个slide切换结束时也运行当前slide动画
          } 
        }

      })  
    $(".swiperContainer2").css({"z-index":101,"position":"absolute","top":0});
  })
  $("#btn6").click(function(){
    $("#btn6 span").attr("class","btnArrow");
    arr[6] = false;
    randomAddClass()
      mySwiper = new Swiper ('.swiperContainer7', {
        direction: 'vertical',
        effect : 'fade',
        fadeEffect: {
          crossFade: false,
        },
        on:{
          init: function(){
            swiperAnimateCache(this); //隐藏动画元素 
            swiperAnimate(this); //初始化完成开始动画
          }, 
          slideChangeTransitionEnd: function(){ 
            swiperAnimate(this); //每个slide切换结束时也运行当前slide动画
          } 
        }

      })  
    $(".swiperContainer7").css({"z-index":101,"position":"absolute","top":0});
  })
  
  $("#btn8").click(function(){
    $("#btn8 span").attr("class","btnArrow");
    arr[2] = false;
    randomAddClass()
      mySwiper = new Swiper ('.swiperContainer3', {
        direction: 'vertical',
        effect : 'fade',
        fadeEffect: {
          crossFade: false,
        },
        on:{
          init: function(){
            swiperAnimateCache(this); //隐藏动画元素 
            swiperAnimate(this); //初始化完成开始动画
          }, 
          slideChangeTransitionEnd: function(){ 
            swiperAnimate(this); //每个slide切换结束时也运行当前slide动画
          } 
        }

      })  
    $(".swiperContainer3").css({"z-index":101,"position":"absolute","top":0});
  })

  $(".returnbtn").click(function(){
    mySwiper.destroy(false);
  })

  $("#submitPageReturn").click(function(){
    $(".submitPage").hide();
  })



var shareUrl = "http://www.newindex.cn/h5/yuexiu_loushu2/index.html";
var shareIamge = "http://www.newindex.cn/h5/yuexiu_loushu2/img/share.jpg?11";
var shareTitle = "越秀·江南悦府微楼书";
var shareDesc = "三轨交汇TOD 苏州首席阿里智能社区";
wxshares(shareUrl, shareIamge, shareTitle, shareDesc);



    window.frameAnimation = {
        anims: function () {
            //var b = frameAnimation.anims($(".effect-container"), 1616, 50, 3.33, 0, 202, 241, 7);
            return function (obj,width,steps,eachtime,times,stepwidth,stepheight,linenum,callback) {
                var runing = false;
                var handler = null;         //obj,width,steps,eachtime,times定时器
                var step = 0;       //当前帧
                var time = 0;       //当前第几轮
                var speed = eachtime*1000/steps;      //间隔时间
                var stepLineNum = 0;  //第几行

                function _play() {
                    if(step >= width/stepwidth){
                        step = 0;
                        stepLineNum++;
                    }
                    // if( stepLineNum < linenum ){
                    if(0 == times || time <times){
                        if (steps<=(stepLineNum*(width/stepwidth)+step)) {
                            stepLineNum = 0;
                            step = 0;
                        }
                        obj.css("background-position", -stepwidth * step + "px " + -stepheight * stepLineNum + "px");
                        step++;
                    }else{
                        control.stop();
                        callback && callback();
                    }

                }

                var control = {
                    start:function(){
                        if(!runing){
                            runing = true;
                            step = time = 0;
                            handler = setInterval(_play, speed);
                        }
                        return this;
                    }

                    ,stop:function(restart){
                        if(runing){
                            runing = false;
                            if(handler){
                                clearInterval(handler);
                                handler = null;
                            }
                            if(restart){
                                obj.css('background-position', '0 0');
                                step = 0;
                                time = 0;
                            }
                        }
                    }
                    ,dispose:function(){
                        this.stop();
                        //console.log('anim dispose');
                    }
                };
                return control;
            }
        }()
    };


$("#clickToSubmitPage").click(function(){
    $(".submitPage").show();
})



var a = frameAnimation.anims($(".lightLogo"), 1599, 50, 3.33, 0, 123, 372, 4);
a.start();
var b = frameAnimation.anims($(".effect-container"), 1616, 50, 3.33, 0, 202, 241, 7);
b.start();



$("#submitBtn").bind("click", function() {
    console.log(123);
    var reg = /^1[0-9]{10}/;
    var username = $("#username").val();
    var telphone = $("#telphone").val();
    if (username == "") {
        alert("请输入姓名！");
    } else {
        if (telphone == "" || !reg.test(telphone)) {
            alert("请输入正确的手机号码！");
        } else {
            $.ajax({
                type: "POST",
                url: "signhandle.php",
                async: true,
                data: {
                    "username": username,
                    "telphone": telphone
                },
                success: function(msg) {
                    var result = JSON.parse(msg);
                    if (result.result == 0) {
                        alert("很抱歉，您已经提交过了！");
                    } else if (result.result == 1) {
                        alert("恭喜您，提交成功！");
                    }else if(result.result == 2){
                        alert("很抱歉，报名人数已满！");
                    }
                }
            });
        }
    }
})